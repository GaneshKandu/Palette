

console.info(cons());

function cons(){
	cons = "///////////////////////////////////////////////////\n";
	cons += "Palatte CMS is a PHP Based Content Management System.\n";
	cons += "Developed By : Ganesh Kandu\n";
	cons += "Contact Mail : kanduganesh@gmail.com\n";
	cons += "///////////////////////////////////////////////////\n";
	cons += "                     .:/++/:.                     \n";
	cons += "                ./yddyo+//oymNs.          .dy`    \n";
	cons += "             -omdo-          -hN/        :NMMN/   \n";
	cons += "          `+dd+`     `/os/`    oM/      oMMMMMMs  \n";
	cons += "        `oNy-       /Ns:/sN:    dN     yNsMMMMMMs \n";
	cons += "       oNs.        .Mo   `Ms    +M-   oM//MMMMMMM`\n";
	cons += "     -mh.          .Ny:/smy`    sM.   MM.oMMMMMMN`\n";
	cons += "    oN/    ./+/`    `+oo/`     :My    yMNNMMMMMm- \n";
	cons += "   ym.    /MMMMN.             /Ms      -oNmdmd:   \n";
	cons += "  sm`     hMMMMM-            +M/         m: oh    \n";
	cons += " :M-      .dMMm+            -M+          N- /d    \n";
	cons += " dy         ``              .Nho:        M+:ym    \n";
	cons += ".M:    `+yyo`                 ./sdy-     MMMMN    \n";
	cons += "/M`   `mMMMMh                     :dy    MMMMN    \n";
	cons += "/M`   :MMMMM+                      `m+   mMMMM    \n";
	cons += ".M:    :syo-                       `N+   dMMMM    \n";
	cons += " sd`          `sdh+               :my    hMMMM    \n";
	cons += "  hh`        `mMMMMs            :hm/     sMMMM    \n";
	cons += "   om/        mMMMm-         -smy:       /MMMM    \n";
	cons += "    .yd+`      -:.       ./ydy/`         `MMMd    \n";
	cons += "      `/yhs+:.`  `.-:+shhs/.              dMMo    \n";
	cons += "          .:+osyyyyso/-                   /MN`    \n";
	cons += "                                           y-     \n";
	cons += "                                                  \n";
return cons;
}