var debug = false;
var output = new Object();

$('#Login').click(function(){login();});
$('#createproject').click(function(){createproject();});
$('#install').click(function(){install();});
$('#createfile').click(function(){createfile();});

function randomStr(m) {
	var m = m || 9; s = '', r = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	for (var i=0; i < m; i++) { s += r.charAt(Math.floor(Math.random()*r.length)); }
	return s;
};

function rmproject(rmproject){
	
	if(!confirm("Are You Sure to Delete")){
		return false;
	}
	
	var rmproject = {
		project:rmproject,
		action:'rmproject'
	};
	$.ajax({
		url : "projects/remove",
		type: "POST",
		data : rmproject,
		success: function(data, textStatus, jqXHR)
		{
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.reload();
			}
			
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.reload();
			}
		}
	});
}

function backup(project){
		
	var backup = {
		project:project,
		action:'backup'
	};
	$.ajax({
		url : "projects/backup",
		type: "POST",
		data : backup,
		success: function(data, textStatus, jqXHR)
		{
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.reload();
			}
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.reload();
			}
		}
	});
}

function download_zip(project){
	var download_zip = {
		project:project,
		action:'backup'
	};
	$.ajax({
		url : "projects/downloadzip",
		type: "POST",
		data : download_zip,
		success: function(data, textStatus, jqXHR)
		{
			if(debug){
				console.log(data);
				console.log(textStatus);
			}
			location.href = ".palette/downloads/"+data;
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			if(debug){
				console.log(data);
				console.log(textStatus);
			}
		}
	});
};


function restore_backup(backup){
	var restore_backup = {
		backup:backup,
		action:'restore_backup'
	};
	$.ajax({
		url : "backup/restore_backup",
		type: "POST",
		data : restore_backup,
		success: function(data, textStatus, jqXHR)
		{
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.reload();
			}
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.reload();
			}
		}
	});
}

function delete_backup(backup){
	var delete_backup = {
		backup:backup,
		action:'delete_backup'
	};
	$.ajax({
		url : "backup/delete_backup",
		type: "POST",
		data : delete_backup,
		success: function(data, textStatus, jqXHR)
		{
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.reload();
			}
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.reload();
			}
		}
	});
}

function createfile(){
	var file = $( "#file" ).val();
	var title = $( "#title" ).val();
	var robots = $( "#robots" ).val();
	var description = $( "#description" ).val();
	var keywords = $( "#keywords" ).val();
	var icon = $( "#icon" ).val();
	var directory = $( "#directory" ).val();
	var baseurl = $( "#baseurl" ).val();
	
	var ProjectData = {
		file:file,
		title:title,
		robots:robots,
		description:description,
		keywords:keywords,
		icon:icon,
		action:'createfile',
		directory:directory,
		baseurl:baseurl,
	};
	$.ajax({
		url : "projects/createfile",
		type: "POST",
		data : ProjectData,
		success: function(data, textStatus, jqXHR)
		{
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.reload();
			}
			
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.reload();
			}
		}
	});
}

function install(){
	
	var admin = $( "#admin" ).val();
	var password = $( "#password" ).val();
	var repassword = $( "#repassword" ).val();
	
	if(password !== repassword){
		echo.alert("Password Doesn't Match");
		return false;
	}
	
	if(password === '' || repassword === '' || admin === ''){
		echo.alert("Fill All Field");
		return false;
	}
	
	if(password.length < 4){
		echo.alert("Password Should be 4 or More Than 4 Character Long");
		return false;
	}

	
	var ProjectData = {
		admin:admin,
		password:password,
		repassword:repassword,
		action:'install'
	};
	$.ajax({
		url : "install.php",
		type: "POST",
		data : ProjectData,
		success: function(data, textStatus, jqXHR)
		{
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.href = "login";
			}
			
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.href = "login";
			}
		}
	});
}

function dialogbox(ctrl){
	
	var posts = {};
	$.ajax({
		url : ctrl,
		type: "POST",
		data : posts,
		success: function(data, textStatus, jqXHR)
		{
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				$("#dialog-shadow").css("display",'block');
				$( "#dialog-body" ).html(data);
			}
			
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				$("#dialog-shadow").css("display",'block');
				$( "#dialog-body" ).html( "<span class='red'>Error Occured</span>" );
			}
		}
	});
}

function createproject(){
	var project = $( "#project" ).val();
	var title = $( "#title" ).val();
	var robots = $( "#robots" ).val();
	var description = $( "#description" ).val();
	var keywords = $( "#keywords" ).val();
	var icon = $( "#icon" ).val();
	
	var ProjectData = {
		newproject:project,
		title:title,
		robots:robots,
		description:description,
		keywords:keywords,
		icon:icon,
		action:'createproject'
	};
	$.ajax({
		url : "projects/createproject",
		type: "POST",
		data : ProjectData,
		success: function(data, textStatus, jqXHR)
		{
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.href = "login";
			}
			
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			if(debug){
				console.log(data);
				console.log(textStatus);
			}else{
				location.href = "login";
			}
		}
	});
}
function login(){
	var user_login = $( "#user_login" ).val();
	var user_password = $("#user_password").val();
	
	var LoginData = {
		user_login:user_login,
		user_password:user_password,
		action:'login'
	};
	$.ajax({
		url : "login/getLogin",
		type: "POST",
		data : LoginData,
		success: function(data, textStatus, jqXHR)
		{
			if(!debug){
				console.log(data);
				console.log(textStatus);
				location.reload();
			}
			
		},
		error: function (jqXHR, textStatus, errorThrown)
		{	
			if(!debug){
				console.log(data);
				console.log(textStatus);
			}
		}
	});
}

console.info(cons());

function cons(){
	cons = "///////////////////////////////////////////////////\n";
	cons += "Palatte CMS is a PHP Based Site Builder.\n";
	cons += "Developed By : Ganesh Kandu\n";
	cons += "Contact Mail : kanduganesh@gmail.com\n";
	cons += "///////////////////////////////////////////////////\n";
	cons += "                     .:/++/:.                     \n";
	cons += "                ./yddyo+//oymNs.          .dy`    \n";
	cons += "             -omdo-          -hN/        :NMMN/   \n";
	cons += "          `+dd+`     `/os/`    oM/      oMMMMMMs  \n";
	cons += "        `oNy-       /Ns:/sN:    dN     yNsMMMMMMs \n";
	cons += "       oNs.        .Mo   `Ms    +M-   oM//MMMMMMM`\n";
	cons += "     -mh.          .Ny:/smy`    sM.   MM.oMMMMMMN`\n";
	cons += "    oN/    ./+/`    `+oo/`     :My    yMNNMMMMMm- \n";
	cons += "   ym.    /MMMMN.             /Ms      -oNmdmd:   \n";
	cons += "  sm`     hMMMMM-            +M/         m: oh    \n";
	cons += " :M-      .dMMm+            -M+          N- /d    \n";
	cons += " dy         ``              .Nho:        M+:ym    \n";
	cons += ".M:    `+yyo`                 ./sdy-     MMMMN    \n";
	cons += "/M`   `mMMMMh                     :dy    MMMMN    \n";
	cons += "/M`   :MMMMM+                      `m+   mMMMM    \n";
	cons += ".M:    :syo-                       `N+   dMMMM    \n";
	cons += " sd`          `sdh+               :my    hMMMM    \n";
	cons += "  hh`        `mMMMMs            :hm/     sMMMM    \n";
	cons += "   om/        mMMMm-         -smy:       /MMMM    \n";
	cons += "    .yd+`      -:.       ./ydy/`         `MMMd    \n";
	cons += "      `/yhs+:.`  `.-:+shhs/.              dMMo    \n";
	cons += "          .:+osyyyyso/-                   /MN`    \n";
	cons += "                                           y-     \n";
	cons += "                                                  \n";
return cons;
}

var echo = new Object();
var ok_id = "palette_popup_ok";
echo.alert = (function(msg){
	$('#palette_popup').css("display","block");
	$('#palette_popup_head').css("display","none");
	$('#palette_popup_Body').html(msg);
});

/*
echo.prompt = (function(msgs){
	wait = true;
	var new_id = randomStr(12);
	$('#palette_popup_head').html(msgs.head);
	$('#'+ok_id).attr("id",new_id);
	ok_id = new_id;
	var html = "<table>";
	for(var i=0;i<msgs.inputs.length;i++){
	    html += "<tr><td>";
		html += msgs.inputs[i];
	    html += "</td><td>";
		html += "<input type=\"text\" id=\"palette_popup_input_"+i+"\" />";
	    html += "</td></tr>";
	}
	html += "</table>";
	$('#palette_popup_Body').html(html);
	$('#palette_popup').css("display","block");
	$('#palette_popup_head').css("display","block");
	return $('#'+new_id);
});
*/

$('#palette_popup_cancel').click(function(){
	$('#palette_popup').css("display","none");
});

$("#palette_popup_ok").click(function(){
	var output = palette_popup_values();
	$('#palette_popup').css("display","none");
});

function palette_popup_values(){
	var i = 0;
	while($('#palette_popup_input_'+i).length){
		output[i] = $('#palette_popup_input_'+i).val();
		i++;
	}
	return output;
}


/*	
	document.getElementById('my').onkeypress = function(event) {
	  this.value = this.value.toUpperCase()
	}
	
	document.getElementById('my').onkeypress = function(event) {
	  this.value = this.value.toUpperCase()
	}
*/