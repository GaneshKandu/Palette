/*
$('*[data-noselect="true"]').focus(
    function () {
        $(this).blur();
    });

$('*[data-noselect="true"] *').focus(
    function () {
        $(this).blur();
});

// Document click blurer
$("#palette_popup").on('mousedown', '*:not(input,textarea)', function() {
	try {
		var $a = $(document.activeElement).prop("disabled", true);
		setTimeout(function() {
			$a.prop("disabled", false);
		});
	} catch (ex) {}
});
*/
/*
=================================================================================
   Base64
=================================================================================
*/
var echo =new Object();
var Base64 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    encode: function(e) {
        var t = "";
        var n, r, i, s, o, u, a;
        var f = 0;
        e = Base64._utf8_encode(e);
        while (f < e.length) {
            n = e.charCodeAt(f++);
            r = e.charCodeAt(f++);
            i = e.charCodeAt(f++);
            s = n >> 2;
            o = (n & 3) << 4 | r >> 4;
            u = (r & 15) << 2 | i >> 6;
            a = i & 63;
            if (isNaN(r)) {
                u = a = 64;
            } else if (isNaN(i)) {
                a = 64;
            }
            t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a);
        }
        return t;
    },
    decode: function(e) {
        var t = "";
        var n, r, i;
        var s, o, u, a;
        var f = 0;
        e = e.replace(/[^A-Za-z0-9+/=]/g, "");
        while (f < e.length) {
            s = this._keyStr.indexOf(e.charAt(f++));
            o = this._keyStr.indexOf(e.charAt(f++));
            u = this._keyStr.indexOf(e.charAt(f++));
            a = this._keyStr.indexOf(e.charAt(f++));
            n = s << 2 | o >> 4;
            r = (o & 15) << 4 | u >> 2;
            i = (u & 3) << 6 | a;
            t = t + String.fromCharCode(n);
            if (u !== 64) {
                t = t + String.fromCharCode(r);
            }
            if (a !== 64) {
                t = t + String.fromCharCode(i);
            }
        }
        t = Base64._utf8_decode(t);
        return t;
    },
    _utf8_encode: function(e) {
        e = e.replace(/rn/g, "n");
        var t = "";
        for (var n = 0; n < e.length; n++) {
            var r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
            } else if (r > 127 && r < 2048) {
                t += String.fromCharCode(r >> 6 | 192);
                t += String.fromCharCode(r & 63 | 128);
            } else {
                t += String.fromCharCode(r >> 12 | 224);
                t += String.fromCharCode(r >> 6 & 63 | 128);
                t += String.fromCharCode(r & 63 | 128);
            }
        }
        return t;
    },
    _utf8_decode: function(e) {
        var t = "";
        var n = 0;
        var r = c1 = c2 = 0;
        while (n < e.length) {
            r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
                n++;
            } else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode((r & 31) << 6 | c2 & 63);
                n += 2;
            } else {
                c2 = e.charCodeAt(n + 1);
                c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                n += 3;
            }
        }
        return t;
    }
};


/*
=================================================================================
	Disable FireFox Default editing feature
=================================================================================
*/

document.execCommand("enableObjectResizing", false, false);

/*
=================================================================================
   Disable Right Click
=================================================================================
*/

$(document).ready(function(){ 
	document.oncontextmenu = function(){return false;};
});

/*
=================================================================================
	Globals
=================================================================================
*/

var debug = false;
var image_1d9e7fa2ed9f534ca43575172ec5ef25 = new Object();
var palette_global_var = new Object();
console.info(cons());

/*
=================================================================================
	Main Function
=================================================================================
*/
function palette(tag){
	html = getHTMLOfSelection();
	UpdateHTML("<"+tag+">"+html+"</"+tag+">");
}

function olist(){
	list = getHTMLOfSelection();
	lis = list.split("<br>");
	html = "";
	for(i = 0;i < lis.length ;i++){
		html += "<li>"+lis[i]+"</li>";
	}
	UpdateHTML("<ol>"+html+"</ol>");
}

function ulist(){
	list = getHTMLOfSelection();
	lis = list.split("<br>");
	html = "";
	for(i = 0;i < lis.length ;i++){
		html += "<li>"+lis[i]+"</li>";
	}
	UpdateHTML("<ul>"+html+"</ul>");
}

function palette(tags,tage){
	html = getHTMLOfSelection();
	if(tage !== 'none'){
		UpdateHTML("<"+tags+">"+html+"</"+tage+">");
	}else{
		UpdateHTML("<"+tags+"/>");
	}
}

function offset(no){
    grid ="\t<div class=\"row cells"+no+"\" >\n";
	for(i = 1;i <= no ; i++){
		grid +="\t\t<div class=\"cell\">"+i+"</div>\n";
	}
	grid +="\t</div>\n";
	UpdateHTML(grid);
}

function addrow(){
	var grids = getgrid();
	grid = "\n<div class=\"grid\">\n";
    grid +="\t<div class=\"row cells12\" >\n";
	for(var i = 0;i < grids.length;i++){
		grid +="\t\t<div class=\"cell colspan"+grids[i]+" \">"+(i+1)+"</div>\n";
	}
	grid +="\t</div>\n";
	grid +="</div>\n";
	UpdateHTML(grid);
}

function palette_save(project,url,dir){
	html = document.getElementById('cont').innerHTML;
	$.post(url+"/projects/save",
	{
	  html: html,
	  project: project
	},
	function(data,status){
		if(data === "success"){
			$.Notify({type: 'success', caption: 'Info', content: "Saved Successfully"});
		}else{
			$.Notify({type: 'warning', caption: 'Warning', content: "Unsuccessfull"});
		}
	});
}

function palette_color(){
	html = getHTMLOfSelection();
	colorvalue = document.getElementById("jscolor").value;
	UpdateHTML("<span style=\"color:#"+ colorvalue +";\">"+html+"</span>");
}

function setForegroundColor(){
	html = getHTMLOfSelection();
	colorvalue = document.getElementById("jscolor").value;
	UpdateHTML("<span style=\"background-color:#"+ colorvalue +";\">"+html+"</span>");
}

function palatte_add_image_url(){
		html = "";	
		result = prompt("Enter Image URL: ", "");
		if(result === null){
			return true;
		}
		if (result === "") {                                             
			echo.alert("Not Enterd any URL");                              
		}else{
			html += "<img src=\""+ result +"\" style=\"width:200px;height:200px;\" />";
			UpdateHTML(html);                         
		}
}

function display_images(){
	if($("#img_exp").css("display") === 'none'){
		$("#img_exp").css("display","block");
	}else{
		$("#img_exp").css("display","none");
	}
}

function palatte_add_image(image_link){
	html = "";
	html += "<img src=\""+ image_link +"\" style=\"width:400px;height:400px;\" />";
	$("#img_exp").css("display","none");
	UpdateHTML(html);
}

function palatte_add_anchor(){
		linkurl = prompt("Enter URL: ", "");
		display = prompt("URL Display: ", ""); 
		if(display === null){
			return true;
		}
		if (display === "") {                                             
			echo.alert("Not Enterd any Anchor");                              
		} else {
			UpdateHTML("<a href=\""+ linkurl +"\" >"+display+"</a>");                         
		}
}

function _palatte_add_anchor(){
	var msgs = new Object();
	msgs.head = "Add Anchor";
	msgs.inputs = [
		"Enter URL",
		"Enter Name to Display URL"
	];
	echo.prompt(msgs).click(function(){
		var output = palette_popup_values();
		__palatte_add_anchor(output[0],output[1]);
	});
}

function __palatte_add_anchor(linkurl,display){
	
		if (display === "") {                                             
			echo.alert("Not Enterd any Anchor");                              
		} else {
			UpdateHTML("<a href=\""+ linkurl +"\" >"+display+"</a>");                         
		}
}

function palatte_add_table(){
		Column = prompt("Enter No of Column", "");
		Rows = prompt("Enter No of Rows", "");  
		if (Rows === "" || Rows === null ){  
			echo.alert("Not Enterd any No of Rows");
			return false;
		}		
		if (Column === "" || Column === null ){  
			echo.alert("Not Enterd any No of Column"); 
			return false;
		}
		
		table = "<table style=\"width:400px;height:400px;\" >";
		k = 1;
		table += "<tr>";
		for(j = 0;j < Column;j++){
			table += "<th>";
				table += k++;
			table += "</th>";
		}
		table += "</tr>";
		for(i = 1;i < Rows;i++){
			table += "<tr>";
				for(j = 0;j < Column;j++){
					table += "<td>";
						table += k++;
					table += "</td>";
				}
			table += "</tr>";
		}
		table += "</table>";
		UpdateHTML(table);                         	
}

function palette_youtube(){
		youtube_link = prompt("Enter HTML Code", "");
		if (youtube_link === "" || youtube_link === null) {                                             
			echo.alert("Not Enterd Any HTML Code");
			return false;			
		} else {
			UpdateHTML(""+
			"<div class=\"video-container\">"+youtube_link+"</div>");			
		}
}

/*
========================================================================
 return selected text
========================================================================
*/
function getSelectionText(){
	    var selectedText = "";
    if (window.getSelection){
		stext = window.getSelection();
		oRange = stext.getRangeAt(0);
		oRect = oRange.getBoundingClientRect();
        selectedText = stext.toString();
    }
	return selectedText;
}


/*
========================================================================
 Replacing html function
========================================================================
*/

function UpdateHTML(html) {
    var range, html;
    if (window.getSelection && window.getSelection().getRangeAt) {
        range = window.getSelection().getRangeAt(0);
        range.deleteContents();
        var div = document.createElement("div");
        div.innerHTML = html;
        var frag = document.createDocumentFragment(), child;
        while ( (child = div.firstChild) ) {
            frag.appendChild(child);
        }
        range.insertNode(frag);
    } else if (document.selection && document.selection.createRange) {
        range = document.selection.createRange();
        range.pasteHTML(html);
    }
}


function getHTMLOfSelection () {
  var range;
  if (document.selection && document.selection.createRange) {
	range = document.selection.createRange();
	return range.htmlText;
  } 
  else if (window.getSelection) {
	var selection = window.getSelection();
	if (selection.rangeCount > 0) {
	  range = selection.getRangeAt(0);
	  var clonedSelection = range.cloneContents();
	  var div = document.createElement('div');
	  div.appendChild(clonedSelection);
	  return div.innerHTML;
	}
	else {
	  return '';
	}
  }
  else {
	return '';
  }
}

/*
========================================================================
 Draging palatte
========================================================================
*/

var selected = null,
    x_pos = 0, y_pos = 0,
    x_elem = 0, y_elem = 0;
// Will be called when user starts dragging an element
function _drag_init(elem) {
    // Store the object of the element which needs to be moved
    selected = elem;
    x_elem = x_pos - selected.offsetLeft;
    y_elem = y_pos - selected.offsetTop;
}
// Will be called when user dragging an element
function _move_elem(e) {
    x_pos = document.all ? window.event.clientX : e.pageX;
    y_pos = document.all ? window.event.clientY : e.pageY;
    if (selected !== null) {
        selected.style.left = (x_pos - x_elem) + 'px';
        selected.style.top = (y_pos - y_elem) + 'px';
    }
}
// Destroy the object when we are done
function _destroy() {
    selected = null;
}
// Bind the functions...
document.getElementById('tool-box').onmousedown = function () {
    _drag_init(this);
    return false;
};

document.onmousemove = _move_elem;
document.onmouseup = _destroy;
/*
=================================================================================
	grid
=================================================================================
*/
$(function (){
  var isMouseDown = false,isHighlighted;
  var x,y;
  var color = ["#ffffff", "#ff5c33", "#ff4d94","#6666ff", "#00ffff", "#ccffcc","#33ff88", "#ff5c88", "#ff4d88","#666688", "#00ff88", "#ccff88","#33ff33"]; 
  $("#our_table td")
    .mousedown(function (){
      isMouseDown = true;
	  x = $(this).attr("box");
	  y = x;
	  var griddb = document.getElementById(x+"_"+y);
	  if(griddb !== null){
		griddb.checked = true;
	  }
	  $(this).css("background-color",color[x]);
      return false;
    })
    .mouseover(function () {
      if (isMouseDown) {
		y = $(this).attr("box");
		document.getElementById(x+"_"+y).checked = true;
		$(this).css("background-color",color[x]);
      }
    });

  $(document)
    .mouseup(function () {
      isMouseDown = false;
    });
});

function getgrid(){
	debug = false;
	var gd = "";
	var grid = Array();
	var k = 0;
	for(var i=1;i<13;i++){
		for(var j=1;j<13;j++){
			gd = $("#"+i+"_"+j+":checked").val();
			if(gd !== undefined){
				grid[k++] = gd;
			}
		}
	}
	var g = Array();
	i = k = 1;j = 0;
	for(i=0;i<12;i++){
		if(grid[i] === grid[(i+1)]){
			k++;
		}else{
			g[j] = k;
			k = 1;
			j++;
		}
	}
	return g;
}

/*
=================================================================================
	Console Logo Diaplay
=================================================================================
*/

function cons(){
	cons = "///////////////////////////////////////////////////\n";
	cons += "Palatte CMS is a PHP Based Site Builder.\n";
	cons += "Developed By : Ganesh Kandu\n";
	cons += "Contact Mail : kanduganesh@gmail.com\n";
	cons += "///////////////////////////////////////////////////\n";
	cons += "                     .:/++/:.                     \n";
	cons += "                ./yddyo+//oymNs.          .dy`    \n";
	cons += "             -omdo-          -hN/        :NMMN/   \n";
	cons += "          `+dd+`     `/os/`    oM/      oMMMMMMs  \n";
	cons += "        `oNy-       /Ns:/sN:    dN     yNsMMMMMMs \n";
	cons += "       oNs.        .Mo   `Ms    +M-   oM//MMMMMMM`\n";
	cons += "     -mh.          .Ny:/smy`    sM.   MM.oMMMMMMN`\n";
	cons += "    oN/    ./+/`    `+oo/`     :My    yMNNMMMMMm- \n";
	cons += "   ym.    /MMMMN.             /Ms      -oNmdmd:   \n";
	cons += "  sm`     hMMMMM-            +M/         m: oh    \n";
	cons += " :M-      .dMMm+            -M+          N- /d    \n";
	cons += " dy         ``              .Nho:        M+:ym    \n";
	cons += ".M:    `+yyo`                 ./sdy-     MMMMN    \n";
	cons += "/M`   `mMMMMh                     :dy    MMMMN    \n";
	cons += "/M`   :MMMMM+                      `m+   mMMMM    \n";
	cons += ".M:    :syo-                       `N+   dMMMM    \n";
	cons += " sd`          `sdh+               :my    hMMMM    \n";
	cons += "  hh`        `mMMMMs            :hm/     sMMMM    \n";
	cons += "   om/        mMMMm-         -smy:       /MMMM    \n";
	cons += "    .yd+`      -:.       ./ydy/`         `MMMd    \n";
	cons += "      `/yhs+:.`  `.-:+shhs/.              dMMo    \n";
	cons += "          .:+osyyyyso/-                   /MN`    \n";
	cons += "                                           y-     \n";
	cons += "                                                  \n";
return cons;
}

function object_resize(result){
	html = "";
	html += "\n<div class=\"resizable\" style=\"cursor: text;\">\n\t";
	html += result;
	html += "\n\t<div class=\"ui-resizable-handle ui-resizable-nw\"></div>\n";
	html += "\t<div class=\"ui-resizable-handle ui-resizable-ne\"></div>\n";
	html += "\t<div class=\"ui-resizable-handle ui-resizable-sw\"></div>\n";
	html += "\t<div class=\"ui-resizable-handle ui-resizable-se\"></div>\n";
	html += "\t<div class=\"ui-resizable-handle ui-resizable-n\"></div>\n";
	html += "\t<div class=\"ui-resizable-handle ui-resizable-s\"></div>\n";
	html += "\t<div class=\"ui-resizable-handle ui-resizable-e\"></div>\n";
	html += "\t<div class=\"ui-resizable-handle ui-resizable-w\"></div>\n";
	html += "</div>";
	return html;
}

/*
=================================================================================
	Pixel Slider
=================================================================================
*/

function dropValueToInput(value, slider){
	$("#slider_input").val(value);
};

/*
=================================================================================
	Image and table resize
=================================================================================
*/

$('.resizable').resizable({
    handles: {
        'nw': '.ui-resizable-nw',
        'ne': '.ui-resizable-ne',
        'sw': '.ui-resizable-sw',
        'se': '.ui-resizable-se',
        'n': '.ui-resizable-n',
        'e': '.ui-resizable-e',
        's': '.ui-resizable-s',
        'w': '.ui-resizable-w'
    }
});

$('.resizable').on('resize', function(e){
	var width  = $(this).width();
	var height = $(this).height();
	$(this).find("table").css("width", width);
    $(this).find("table").css("height", height);
});

$( '.draggable' ).draggable().on('click', function(){
    if ( $(this).is('.ui-draggable-dragging') ) {
        return;
    } else {
        $(this).draggable( 'option', 'disabled', true );
        //$(this).prop('contenteditable','true');
        $(this).css('cursor', 'text');
    }
}).on('blur', function(){
    $(this).draggable( 'option', 'disabled', false);
    $(this).prop('contenteditable','false');
    $(this).css('cursor', 'move');
});

$(document).on('dblclick','img',(function(){
	var width  = $(this).width();
	var height = $(this).height();
	var position = $(this).offset();
	var left = position.left;
	var top = position.top;
	$('.resizable').css("display",'block');
	$('.resizable').css("width", width+5);
	$('.resizable').css("height", height+5);
	$('.resizable').css("left", left);
	$('.resizable').css("top", top);
	image_1d9e7fa2ed9f534ca43575172ec5ef25 = $(this);
}));

$(document).on('dblclick','table',(function(){
	var width  = $(this).width();
	var height = $(this).height();
	var position = $(this).offset();
	var left = position.left;
	var top = position.top;
	$('.resizable').css("display",'block');
	$('.resizable').css("width", width+5);
	$('.resizable').css("height", height+5);
	$('.resizable').css("left", left);
	$('.resizable').css("top", top);
    //$(this).prop('contenteditable','true');
	image_1d9e7fa2ed9f534ca43575172ec5ef25 = $(this);
}));

$(".resizable").dblclick(function(){
	$(this).css("display",'none');
    $(this).prop('contenteditable','false');
});

$('.resizable').on('resize', function(e){
	var width  = $(this).width();
	var height = $(this).height();
	image_1d9e7fa2ed9f534ca43575172ec5ef25.css("width", width);
    image_1d9e7fa2ed9f534ca43575172ec5ef25.css("height", height);
	var position = image_1d9e7fa2ed9f534ca43575172ec5ef25.offset();
	var left = position.left;
	var top = position.top;
	$(this).css("left", left);
	$(this).css("top", top);
});

/*
=================================================================================
	option on selecting text
=================================================================================
*/

$(function(){
    $(document.body).bind('mouseup', function(e){
        var selection;
        if (window.getSelection) {
          selection = window.getSelection();
        } else if (document.selection) {
          selection = document.selection.createRange();
        }
    });
});

$("#close_button").click(function(){
	$("#dialog-shadow").css("display",'none');
});
/*
=================================================================================
   Contex Menu
=================================================================================
*/

$('.grid').bind('mousedown',function(e){ 
	if( e.button === 2 ) {
		var palatte_contex = $("#palatte_contex");
		var selected_text = getSelectionText();
		palette_global_var = $(this);
		if(selected_text !== ""){
			// run when text is selected
			var title = "Selected Text Menu";
			var icons = ["mif-palette","mif-palette",""];
			var names = ["Set Background Color","Set Foreground Color","Set Font Size"];
			var method = ["setForegroundColor()","palette_color()","setFontSize()"];
		}else{
			// run when text is not selected
			var title = "Grid Menu";
			var icons = ["mif-image","mif-image","mif-palette","mif-stack2"];
			var names = ["Set Background Image","Set Background Image URL","Set Background Color","Set Border"];
			var method = ["setBackground()","setBackground_URL()","setBackgroundColor()","setBorder()"];
		}
		var contex = create_contex_menu(title,icons,names,method);
		palatte_contex.html(contex);
		palatte_contex.css("display",'block');	
		palatte_contex.css("top",e.pageY);	
		palatte_contex.css("left",e.pageX);
		return false; 
	} 
return true; 
}); 

$('img').bind('mousedown',function(e){ 
	if( e.button === 2 ) {
		var palatte_contex = $("#palatte_contex");
		palette_global_var = $(this);
		var title = "Image Menu";
		var icons = ["mif-stack2"];
		var names = ["Set Border"];
		var method = ["setImageBorder()"];
		var contex = create_contex_menu(title,icons,names,method);
		palatte_contex.html(contex);
		palatte_contex.css("display",'block');	
		palatte_contex.css("top",e.pageY);	
		palatte_contex.css("left",e.pageX);
		return false; 
	} 
return true; 
}); 

$('tbody').bind('mousedown',function(e){ 
	if( e.button === 2 ) {
		palette_global_var = $(this);
		var selected_text = getSelectionText();
		var palatte_contex = $("#palatte_contex");
		// run when text is not selected
		if(selected_text === ""){
			var title = "Table Menu";
			var icons = [
				"mif-stack2",
				"mif-image",
				"mif-image",
				"mif-palette",
				"mif-palette",
				"mif-stack2",
				"mif-image",
				"mif-image",
				"mif-palette",
				"mif-palette",
				"mif-stack2",
				"mif-image",
				"mif-image",
				"mif-palette",
				"mif-palette"
				];
			var names = [
				"Table Border",
				"Table Background Image",
				"Table Background Image URL",
				"Table Background Color",
				"Table Text Color",
				"Heading Border",
				"Heading Background Image",
				"Heading Background Image URL",
				"Heading Background Color",
				"Heading Text Color",
				"Body Border",
				"Body Background Image",
				"Body Background Image URL",
				"Body Background Color",
				"Body Text Color"
				];
			var method = [
				"setTableBorder()",
				"setBackground()",
				"setBackground_URL()",
				"setBackgroundColor()",
				"setTableTextColor()",
				"setThBorder()",
				"setThBackgroundImage()",
				"setBackgroundTH_URL()",
				"setThBackgroundColor()",
				"setThTextColor()",
				"setTdBorder()",
				"setTdBackgroundImage()",
				"setBackgroundTD_URL()",
				"setTdBackgroundColor()",
				"setTdTextColor()"
				];
		}else{
			//Selected Text Menu
			var title = "Selected Text Menu";
			var icons = ["mif-palette","mif-palette",""];
			var names = ["Set Background Color","Set Foreground Color","Set Font Size"];
			var method = ["setForegroundColor()","palette_color()","setFontSize()"];
		}
		var contex = create_contex_menu(title,icons,names,method);
		palatte_contex.html(contex);
		palatte_contex.css("display",'block');	
		palatte_contex.css("top",e.pageY);	
		palatte_contex.css("left",e.pageX);
		return false; 
	} 
	return true; 
});

function palatte_contex_close(){
	$("#palatte_contex").css("display",'none');
};

$("#palatte_contex").focusout(function() {
	$(this).css("display",'none');
}).mouseleave(function() {
	$(this).css("display",'none');
});

function create_contex_menu(title,icons,names,method){
	html = "";
	html += "<li class=\"menu-title\">"+title+"</li>";
	for(var i=0;i < icons.length;i++){
		html +="<li><a href=\"javascript:void(0)\" onclick=\""+ method[i] +";palatte_contex_close();\" ><span class=\""+ icons[i] +" icon\"></span>"+ names[i] +"</a></li>";
	}
	html += "<li><a href=\"javascript:void(0)\" onclick=\"palatte_contex_close();\" ><span class=\"mif-cross icon\"></span>Close</a></li>";
	return html;
};


/*
=================================================================================
   context menu dialogs
=================================================================================
*/

function setImage(image_link){
	if(palette_global_var !== undefined){
		if(typeof palette_global_var.css === 'function'){
			palette_global_var.css("background-image","url(\""+image_link+"\")");
		}else{
			palatte_add_image(image_link);
		}
		palette_global_var = undefined;
	}else{
		palatte_add_image(image_link);
	}
	$("#img_exp").css("display","none");
}

function setBackground(){
	display_images();
};

function setBackgroundTD_URL(){
	palette_global_var = palette_global_var.find("td");
	setBackground_URL();
};

function setBackgroundTH_URL(){
	palette_global_var = palette_global_var.find("th");
	setBackground_URL();
};

function setBackground_URL(){
	result = prompt("Enter Background Image URL: ", "");
	if (result === "" || result === null) {                                          
		echo.alert("Not Enterd any URL");                              
	}else{
		result = "url(\""+result+"\")";
		palette_global_var.css("background-image",result);
	}
};

function setBackgroundColor(){
	colorvalue = "#"+document.getElementById("jscolor").value;
	palette_global_var.css("background-color",colorvalue);
}

function setTextColor(){
	colorvalue = "#"+document.getElementById("jscolor").value;
	palette_global_var.css("color",colorvalue);
}

function setBorder(){
	colorvalue = "#"+document.getElementById("jscolor").value;
	border_type = $("input:radio[name=radio_palette_border]:checked").val();
	palette_global_var.css("border-style",border_type);
	palette_global_var.css("border-color",colorvalue);
}

function setImageBorder(){
	colorvalue = "#"+document.getElementById("jscolor").value;
	pixel = document.getElementById("slider_input").value;
	border_type = $("input:radio[name=radio_palette_border]:checked").val();
	palette_global_var.css("border",pixel+"px "+border_type+" "+colorvalue);
}

function setTableBorder(){
	colorvalue = "#"+document.getElementById("jscolor").value;
	pixel = document.getElementById("slider_input").value;
	border_type = $("input:radio[name=radio_palette_border]:checked").val();
	palette_global_var.css("border",pixel+"px "+ border_type +" "+colorvalue);
}

function setTableTextColor(){
	setTextColor();
};

function setThBorder(){
	palette_global_var = palette_global_var.find("th");
	setTableBorder();
};

function setThBackgroundImage(){
	palette_global_var = palette_global_var.find("th");
	setBackground();
};

function setThBackgroundColor(){
	palette_global_var = palette_global_var.find("th");
	setBackgroundColor();
};

function setThTextColor(){
	palette_global_var = palette_global_var.find("th");
	setTextColor();
};

function setTdBorder(){
	palette_global_var = palette_global_var.find("td");
	setTableBorder();
};

function setTdBackgroundImage(){
	palette_global_var = palette_global_var.find("td");
	setBackground();
};

function setTdBackgroundColor(){
	palette_global_var = palette_global_var.find("td");
	setBackgroundColor();
};

function setTdTextColor(){
	palette_global_var = palette_global_var.find("td");
	setTextColor();
};

function setFontSize(){
	html = getHTMLOfSelection();
	pixel = document.getElementById("slider_input").value;
	UpdateHTML("<span style=\"font-size:"+ pixel +"px;\" >"+html+"</span>");
}
