#Screeshot how to use pallate

# Getting Started

+ [Griding](#griding)
+ [Image Resize](#image-resize)
+ [Designing Table](#designing-table)
+ [Text Coloring](#text-coloring)
+ [Adding Image](#adding-image)
+ [Border](#border)


## Griding

* you can use any combination of grid you want for your page by just selection of grid open given in grid button

![](https://github.com/GaneshKandu/Palette/blob/master/images/SCREENSHOTS (6).gif)

## Image Resize

* Resize Image by double click on it

![](https://github.com/GaneshKandu/Palette/blob/master/images/SCREENSHOTS (1).gif)

## Designing Table

* insert table from table option and Resize table by double click on it and resize
* right click on table for get more option

![](https://github.com/GaneshKandu/Palette/blob/master/images/SCREENSHOTS (2).gif)

## Text Coloring

* get option for Changing forground and background colour just by selecting text and right click on selected text

![](https://github.com/GaneshKandu/Palette/blob/master/images/SCREENSHOTS (3).gif)

## Adding Image

* Add image click on image icon on toolbox will give you all list of your uploaded images
* just click image where you want and right click and get option

![](https://github.com/GaneshKandu/Palette/blob/master/images/SCREENSHOTS (4).gif)

## Border

* right click on images and table and get all combination of border you want

![](https://github.com/GaneshKandu/Palette/blob/master/images/SCREENSHOTS (5).gif)

