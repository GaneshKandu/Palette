<?php 

/*
///////////////////////////////////////////////////
Palatte is a PHP Based Site Builder
Developed By : Ganesh Kandu
Contact Mail : kanduganesh@gmail.com
///////////////////////////////////////////////////
*/


	include 'contents.php';
	include $tpl['content'].'.php';
	include 'contente.php'; 

?>
