                </div>
            </div>
        </div>
    </div>
<?php 
$n = new notify();
$n->get_notification();
?>
<script src="js/palettecms.js"></script>
</body>
</html>