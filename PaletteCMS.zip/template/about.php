<h3 class="text-light"><?php echo $tpl['lang']['About']; ?><span class="mif-palette place-right"></span></h3>
<hr class="thin bg-grayLighter"/>
<table>
<tr><td><h4><?php echo $tpl['lang']['Developer']; ?></h4></td><td>:   </td><td><h4>Ganesh Kandu</h4></td></tr>
<tr><td><h4><?php echo $tpl['lang']['language']; ?></h4></td><td>:   </td><td><h4><?php echo $tpl['lang']['Auto-lang']; ?></h4></td></tr>
<tr><td><h4><?php echo $tpl['lang']['Mail']; ?></h4></td><td>:</td><td><h4><a TARGET="_blank" href="mailto:kanduganesh@gmail.com">kanduganesh@gmail.com</a></h4></td></tr>
<tr><td><h4><?php echo $tpl['lang']['Issues']; ?></h4></td><td>:</td><td><h4><a TARGET="_blank" href="https://github.com/GaneshKandu/Palette/issues/new"><?php echo $tpl['lang']['Issues']; ?></a></h4></td></tr>
<tr><td><h4><?php echo $tpl['lang']['Developed_By']; ?></h4></td><td>:</td><td><h4>Ganesh Kandu</h4></td></tr>
<tr><td><h4>Version</h4></td><td>:</td><td><h4><?php echo VERSION; ?></h4></td></tr>
</table>
<hr class="thin bg-grayLighter"/>
<h3 class="text-light"><?php echo $tpl['lang']['Created_Using']; ?></h3>
<table>
<tr><th><h4>      Apps      </h4></th><th><h4>      Version      </h4></th><th><h4>      Link      </h4></th></tr>
<tr><td><h4>Metro UI</h4></td><td><h4>3.0</h4></td><td><h4><a TARGET="_blank" href="http://metroui.org.ua/">http://metroui.org.ua/</a></h4></td></tr>
<tr><td><h4>JQuery</h4></td><td><h4>2.1.3</h4></td><td><h4><a TARGET="_blank" href="https://jquery.com/">https://jquery.com/</a></h4></td></tr>
<tr><td><h4>JSColor</h4></td><td><h4>2.4.0</h4></td><td><h4><a TARGET="_blank" href="http://jscolor.com/">http://jscolor.com/</a></h4></td></tr>
<tr><td><h4>DropzoneJS</h4></td><td><h4>4.3.0</h4></td><td><h4><a TARGET="_blank" href="http://www.dropzonejs.com">http://www.dropzonejs.com</a></h4></td></tr>
</table>