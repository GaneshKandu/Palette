<hr class="thin bg-grayLighter">
<h1 class="text-light">404 <?php echo $tpl['lang']['nf']; ?><span class="mif-palette place-right"></span></h1>
<img src="images/404.png" style="width:400px; height:300px;">
<hr class="thin bg-grayLighter">