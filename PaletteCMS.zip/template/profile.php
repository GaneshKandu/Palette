<h1 class="text-light"><?php echo $tpl['lang']['Profile']; ?><span class="mif-palette place-right"></span></h1>
<hr class="thin bg-grayLighter"/>

